
let element = document.getElementById('khazana');
element.addEventListener("mouseenter", () => {
    element.style.backgroundColor = "rgb(190, 5, 5)";
});
element.addEventListener("mouseleave", () => {
    element.style.backgroundColor = "rgb(50, 18, 77)";
});
